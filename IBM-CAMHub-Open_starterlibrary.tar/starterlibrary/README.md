[//]: # (Licensed Materials - Property of IBM)
[//]: # ((C) Copyright IBM Corp. 2017, 2018. All Rights Reserved.)
[//]: # (US Government Users Restricted Rights - Use, duplication or)
[//]: # (disclosure restricted by GSA ADP Schedule Contract with IBM Corp.)
# starterlibrary
Starter library templates for various cloud providers
