=======
Summary
=======

This Terraform sample will perform a single-VM deployment in OpenStack
