# Pattern Build Repository

Copyright IBM Corp. 2018, 2018

This is a multi-purpose repository that is contains scripts that are used by templates and cookbooks during the build process.  Also contains scripts
for creating cloud connections and content runtimes. 

For creating content runtimes, please see the tasks/creatgingContentRuntimes.md

